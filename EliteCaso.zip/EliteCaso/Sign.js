// Firebase config
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Elements
const signupBtn = document.getElementById("signup-btn");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const emailError = document.getElementById("email-error");
const passwordError = document.getElementById("password-error");
const usernameError = document.getElementById("username-error");
const spinner = document.getElementById("signup-spinner");
const btnText = document.getElementById("btn-text");
const togglePassword = document.getElementById("togglePassword");

// Toggle Password
togglePassword.addEventListener("click", () => {
  password.type = password.type === "password" ? "text" : "password";
});

// Signup Logic
signupBtn.addEventListener("click", async () => {
  emailError.textContent = "";
  passwordError.textContent = "";
  usernameError.textContent = "";

  const emailVal = email.value.trim();
  const passVal = password.value.trim();
  const userVal = username.value.trim();

  if (!userVal) {
    usernameError.textContent = "Username is required.";
    return;
  }

  if (!emailVal) {
    emailError.textContent = "Email is required.";
    return;
  }

  if (!passVal || passVal.length < 6) {
    passwordError.textContent = "Password must be at least 6 characters.";
    return;
  }

  signupBtn.disabled = true;
  spinner.classList.remove("hidden");
  btnText.textContent = "Creating...";

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, emailVal, passVal);
    const uid = userCredential.user.uid;

    // Create Firestore user document
    await setDoc(doc(db, "users", uid), {
      username: userVal,
      balance: 0,
      streakDay: 0,
      lastClaimed: null,
      role: "user",
      createdAt: serverTimestamp()
    });

    // 🎉 Confetti animation
    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 }
    });

    // Redirect after short delay
    setTimeout(() => {
      window.location.href = "index.html";
    }, 2000);
  } catch (error) {
    const err = error.message;
    if (err.includes("auth/email-already-in-use")) {
      emailError.textContent = "Email already in use.";
    } else {
      passwordError.textContent = "Signup failed. Try again.";
    }
  }

  signupBtn.disabled = false;
  spinner.classList.add("hidden");
  btnText.textContent = "Sign Up";
});