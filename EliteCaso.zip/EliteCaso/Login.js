// Firebase Config
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Elements
const loginBtn = document.getElementById("login-btn");
const emailField = document.getElementById("email");
const passwordField = document.getElementById("password");
const emailError = document.getElementById("email-error");
const passwordError = document.getElementById("password-error");
const spinner = document.getElementById("login-spinner");
const btnText = document.getElementById("btn-text");

// Login Event
loginBtn.addEventListener("click", async () => {
  const email = emailField.value.trim();
  const password = passwordField.value;

  // Clear old errors
  emailError.textContent = "";
  passwordError.textContent = "";

  if (!email) {
    emailError.textContent = "Email is required.";
    return;
  }

  if (!password) {
    passwordError.textContent = "Password is required.";
    return;
  }

  loginBtn.disabled = true;
  spinner.classList.remove("hidden");
  btnText.textContent = "Logging in...";

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const uid = userCredential.user.uid;

    // Fetch user data
    const userDoc = await getDoc(doc(db, "users", uid));
    if (userDoc.exists()) {
      const userData = userDoc.data();
      console.log("Welcome,", userData.username);

      // Redirect
      window.location.href = "dashboard.html";
    } else {
      console.error("User data not found.");
    }
  } catch (error) {
    const err = error.message;
    if (err.includes("auth/invalid-email")) {
      emailError.textContent = "Invalid email address.";
    } else if (err.includes("auth/user-not-found")) {
      emailError.textContent = "No user found with this email.";
    } else if (err.includes("auth/wrong-password")) {
      passwordError.textContent = "Incorrect password.";
    } else {
      passwordError.textContent = "Login failed. Try again.";
    }
  }

  loginBtn.disabled = false;
  spinner.classList.add("hidden");
  btnText.textContent = "Login";
});