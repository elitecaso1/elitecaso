import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

// 🔐 Your Firebase Config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Minimum splash time (5 seconds)
const splashStart = Date.now();
const MIN_SPLASH_TIME = 5000;

onAuthStateChanged(auth, user => {
  const timeElapsed = Date.now() - splashStart;
  const delay = Math.max(0, MIN_SPLASH_TIME - timeElapsed);

  setTimeout(() => {
    if (user) {
      window.location.href = "dashboard.html";
    } else {
      window.location.href = "login.html";
    }
  }, delay);
});