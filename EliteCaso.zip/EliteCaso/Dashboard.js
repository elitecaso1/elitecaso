// ✅ Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// ✅ Your Firebase config (replace with yours)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MSG_ID",
  appId: "YOUR_APP_ID"
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();
const db = getFirestore(app);

// ✅ DOM Elements
const userNameEl = document.getElementById("userName");
const userBalanceEl = document.getElementById("userBalance");
const notifDot = document.getElementById("notifDot");
const notifBell = document.getElementById("notifBell");

// ✅ Monitor Auth State
onAuthStateChanged(auth, async (user) => {
  if (user) {
    try {
      const userDocRef = doc(db, "users", user.uid);
      const docSnap = await getDoc(userDocRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        userNameEl.textContent = data.username || "Player";
        userBalanceEl.textContent = data.balance || "0";

        // Show 🔔 notification dot if there are new notifs
        if (data.hasUnreadNotif) {
          notifDot.style.display = "block";
        }
      } else {
        console.log("No user data found.");
      }
    } catch (err) {
      console.error("Error getting user data:", err);
    }
  } else {
    // ✅ No redirect, just log status
    console.warn("User not logged in.");
    userNameEl.textContent = "Guest";
    userBalanceEl.textContent = "0";
  }
});

// 🛎️ Toggle notification dot on bell click
notifBell?.addEventListener("click", () => {
  notifDot.style.display = "none";
});

// 🎲 Game Redirection (Optional - if not using HTML onclick directly)
document.querySelectorAll(".game-card").forEach((card) => {
  card.addEventListener("click", () => {
    const gameName = card.getAttribute("data-game");
    if (gameName === "dice") {
      window.location.href = "dice.html";
    } else if (gameName === "coinflip") {
      window.location.href = "coinflip.html";
    } else if (gameName === "roulette") {
      window.location.href = "roulette.html";
    }
  });
});