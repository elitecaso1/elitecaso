// Firebase Init
let user = null;
let userId = null;
let userBalance = 0;
let soundEnabled = true;
let cooldown = false;
let jackpot = 0;

const db = firebase.firestore();
const auth = firebase.auth();

// UI Elements
const dice = document.getElementById('dice');
const rollBtn = document.getElementById('rollBtn');
const amountInput = document.getElementById('betAmount');
const cooldownTimer = document.getElementById('cooldownTimer');
const message = document.getElementById('message');
const popup = document.getElementById('popup');
const historyList = document.getElementById('historyList');
const jackpotText = document.getElementById('jackpot');
const soundBtn = document.getElementById('soundToggle');
const themeBtn = document.getElementById('themeToggle');

// Load sound
const diceSound = new Audio('https://cdn.pixabay.com/download/audio/2022/10/12/audio_4b9e8b56c1.mp3');

// Theme Handling
function loadTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  document.body.classList.toggle('light-theme', saved === 'light');
}

themeBtn.addEventListener('click', () => {
  document.body.classList.toggle('light-theme');
  localStorage.setItem('theme', document.body.classList.contains('light-theme') ? 'light' : 'dark');
});

// Sound toggle
soundBtn.addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  soundBtn.innerText = soundEnabled ? '🔔 Sound On' : '🔕 Sound Off';
});

// Show popup
function showPopup(msg, isWin = false) {
  popup.innerText = msg;
  popup.classList.remove('hidden');
  popup.className = 'popup ' + (isWin ? 'win' : 'lose');
  setTimeout(() => popup.classList.add('hidden'), 3000);
}

// Update balance UI
function updateBalanceUI() {
  document.getElementById('balance').innerText = userBalance.toFixed(2);
}

// Fetch and display user info
function loadUserData() {
  auth.onAuthStateChanged(async (u) => {
    if (u) {
      user = u;
      userId = u.uid;

      const doc = await db.collection('users').doc(userId).get();
      const data = doc.data();

      if (data) {
        userBalance = data.balance || 0;
        jackpot = data.jackpot || 0;

        document.getElementById('username').innerText = data.username || user.email;
        document.getElementById('minAmount').innerText = '10';
        document.getElementById('maxAmount').innerText = '1000';
        updateBalanceUI();
        updateJackpot();
      }
    }
  });
}

function updateJackpot() {
  jackpotText.innerText = jackpot.toFixed(2);
}

// Add to history
function addHistory(entry) {
  const li = document.createElement('li');
  li.textContent = entry;
  historyList.prepend(li);
}

// Roll logic
rollBtn.addEventListener('click', async () => {
  if (cooldown || !user) return;

  const amount = parseFloat(amountInput.value);
  if (isNaN(amount) || amount < 10 || amount > 1000) {
    showPopup("❗ Bet must be ₹10 - ₹1000");
    return;
  }

  if (amount > userBalance) {
    showPopup("❌ Insufficient balance!");
    return;
  }

  // Cooldown start
  cooldown = true;
  rollBtn.disabled = true;
  cooldownTimer.classList.add('visible');
  let timeLeft = 5;
  cooldownTimer.innerText = `⏳ Cooldown: ${timeLeft}s`;
  const interval = setInterval(() => {
    timeLeft--;
    cooldownTimer.innerText = `⏳ Cooldown: ${timeLeft}s`;
    if (timeLeft === 0) {
      clearInterval(interval);
      cooldown = false;
      rollBtn.disabled = false;
      cooldownTimer.classList.remove('visible');
    }
  }, 1000);

  // Play sound
  if (soundEnabled) diceSound.play();

  // Animate dice
  dice.classList.add('shake');
  setTimeout(() => dice.classList.remove('shake'), 500);

  // Random roll
  const roll = Math.floor(Math.random() * 6) + 1;
  dice.innerText = roll;

  // Determine outcome (e.g., win on 4,5,6)
  const isWin = roll >= 4;
  const reward = isWin ? amount * 0.2 : 0;
  const newBalance = isWin ? userBalance + reward : userBalance - amount;
  const jackpotIncrease = isWin ? 0 : amount * 0.05;

  userBalance = newBalance;
  jackpot += jackpotIncrease;

  // Update Firestore
  await db.collection('users').doc(userId).update({
    balance: userBalance,
    jackpot
  });

  updateBalanceUI();
  updateJackpot();

  const outcomeText = isWin
    ? `🎉 You rolled ${roll} and won ₹${reward.toFixed(2)}!`
    : `😢 You rolled ${roll} and lost ₹${amount.toFixed(2)}`;

  showPopup(outcomeText, isWin);
  addHistory(outcomeText);
});

// Load everything
window.onload = () => {
  loadTheme();
  loadUserData();
};